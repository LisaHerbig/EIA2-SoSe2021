"use strict";
var Endaufgabe_FußballSiumulation;
(function (Endaufgabe_FußballSiumulation) {
    class Moveable {
        //radius: number;
        constructor(_position) {
            this.position = _position;
        }
    }
    Endaufgabe_FußballSiumulation.Moveable = Moveable;
})(Endaufgabe_FußballSiumulation || (Endaufgabe_FußballSiumulation = {}));
//# sourceMappingURL=Moveable.js.map